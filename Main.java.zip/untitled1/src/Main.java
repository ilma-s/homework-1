import java.io.File;
import java.io.IOException;
import java.util.*;

//cheapest shared room: sort by price lowest and grab/print the first element -- collections.sort
//key: price    value: room object?

//most expensive private room in a radius of 10 kilometers from big ben
// key: price    value: room object with room type of private room
//big ben coordinates: 51.5007° N, 0.1246° W - izracunati udaljenost izmedju dvije tacke: ako je veca od 10km - false
//collections.reverse and print the first one

//accommodation located in the middle of a list for all places that have London in their name: map: key has the word London in it, value is the entire room object
//print the middle element (length/2 za parne, length/2 + 1 za neparne)

public class Main {
    public static void main(String[] args) throws IOException{
         File file = new File("airbnb.txt");
         Scanner s = new Scanner(file);

         ArrayList<room> rooms = new ArrayList<>();
         Map<String, ArrayList<room>> cheapestRoom = new HashMap<>();
        Map<String, ArrayList<room>> mostExpensiveRoom = new HashMap<>();

         s.nextLine();
         while(s.hasNextLine()) {
             String line = s.nextLine();
             String[] elements = line.split("\t");
             if(elements.length < 10) s.nextLine();
             else {
                 String name = elements[1].trim();
                 Double lat = Double.parseDouble(elements[5].trim());
                 Double lon = Double.parseDouble(elements[6].trim());
                 Integer price = Integer.parseInt(elements[8].trim());

                 rooms.add(new room(name, lat, lon, price));

                 if (!cheapestRoom.containsKey(name)) {
                     cheapestRoom.put(name, new ArrayList<>());
                 }

                 room r = new room(name, lat, lon, price);
                 cheapestRoom.get(name).add(r);
             }
                sortArray(rooms);

                 for (Map.Entry<String, ArrayList<room>> entry : cheapestRoom.entrySet()) {
                     Collections.sort(entry.getValue());
                     Collections.reverse(entry.getValue());

//            System.out.println(entry.getValue().get(0));
                     for (room r1 :
                             entry.getValue().size() > 5 ?
                                     entry.getValue().subList(0,1) :
                                     entry.getValue()) {
                         System.out.println(entry.getKey() + "-" + entry.getValue());
                     }
                 }


             }
         }

    private static void sortArray(ArrayList<room> rooms) throws IOException {
        Collections.sort(rooms);
        Collections.reverse(rooms);

        for (room r : rooms) {
            System.out.println(r);
        }

        /*room r1 = new room("r1", 0.5, 0.9, 900);
        room r2 = new room("r2", 0.8, 0.9, 1000);
        System.out.println(r1.compareTo(r2));*/
    }

    private static boolean hasLondonInName(String key) {
        if (key.contains("London")) return true;
        return false;
    }

    private static Double distanceFromBigBen(Double lat, Double lon) {
        return Math.sqrt((lat-51.51)*(lat-51.51) + (lon+0.12)*(lon+0.12));
    }
}