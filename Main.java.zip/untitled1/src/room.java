public class room implements Comparable<room> {
    private final String name;
    private final Double lat;
    private final Double lon;
    private final Integer price;

    public room(String name, Double lat, Double lon, Integer price) {
        this.name = name;
        this.lat = lat;
        this.lon = lon;
        this.price = price;
    }

    @Override
    public int compareTo(room r) {
        return this.price.compareTo(r.price);
    }
}
