public interface room1 {
    int compareTo(room r);
}
